#ifndef VERTEX
#define VERTEX

struct Vertex {
    float x;
    float y;
    float z;
    float nx;
    float ny;
    float nz;
};

#endif // VERTEX

