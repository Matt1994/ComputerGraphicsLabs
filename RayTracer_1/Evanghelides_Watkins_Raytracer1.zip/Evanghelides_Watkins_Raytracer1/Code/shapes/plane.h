#ifndef EXAMPLE_H_
#define EXAMPLE_H_

#include "../object.h"

class Plane: public Object
{
    public:
        Plane(Point const &point, Vector const &d1, Vector const &d2);

        virtual Hit intersect(Ray const &ray);

		Point  const point;
        Vector const direction1;
        Vector const direction2;
};

#endif
